import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CompleteinventoryPage } from './completeinventory';

@NgModule({
  declarations: [
    CompleteinventoryPage,
  ],
  imports: [
    IonicPageModule.forChild(CompleteinventoryPage),
  ],
})
export class CompleteinventoryPageModule {}
