import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddbundlePage } from './addbundle';

@NgModule({
  declarations: [
    AddbundlePage,
  ],
  imports: [
    IonicPageModule.forChild(AddbundlePage),
  ],
})
export class AddbundlePageModule {}
