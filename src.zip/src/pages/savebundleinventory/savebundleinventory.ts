import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { RestApiProvider } from '../../providers/rest-api/rest-api';

/**
 * Generated class for the SavebundleinventoryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-savebundleinventory',
  templateUrl: 'savebundleinventory.html',
})
export class SavebundleinventoryPage {
  current: any[];
  completeinventory: string[];
  currentvalue = 0;
  lastvalue = 0;
    constructor(public navCtrl: NavController, public navParams: NavParams, public rest: RestApiProvider) {}

    ionViewDidLoad() {
        console.log('ionViewDidLoad CompleteinventoryPage');

        this.getCompleteInventory();
       
  this.currentvalue = 0;
  this.current = this.completeinventory;
    }
    
    errorMessage() {

    }
    getCompleteInventory() {
        this.rest.getCompleteInventory()
            .subscribe(
                completeinventory => this.completeinventory = completeinventory,
                error => this.errorMessage = < any > error);
    }

    next(): void {
      this.lastvalue = this.completeinventory.length - 1;
      this.currentvalue = this.currentvalue + 1;
    }
    previous(): void {
      this.lastvalue = this.completeinventory.length - 1;
      this.currentvalue = this.currentvalue - 1;
    }

    onSearchChange(newValue) : void {
      console.log(newValue)
    }
  
    gettotal(): void {
      var arr = document.getElementsByClassName("value");
      var tot=0;
      for(var i=0;i<arr.length;i++){
          debugger;
          // if ( parseInt(arr[i].value ) ) {
          //     tot += parseInt(arr[i].value);
          // }
      }
      console.log(tot);
    }

}
